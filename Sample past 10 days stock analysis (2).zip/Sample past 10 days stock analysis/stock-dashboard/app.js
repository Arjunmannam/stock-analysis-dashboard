document.getElementById('uploadBtn').addEventListener('click', () => {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];

    if (!file) {
        alert('Please select a CSV file.');
        return;
    }

    Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: function(results) {
            const data = results.data;

            // Filter valid rows (date and close not null)
            const filteredData = data.filter(row => row.date && row.close);

            const labels = filteredData.map(row => row.date);
            const closingPrices = filteredData.map(row => parseFloat(row.close));

            updateChart(labels, closingPrices);
        }
    });
});

let chart;
function updateChart(labels, dataPoints) {
    const ctx = document.getElementById('stockChart').getContext('2d');

    // Destroy existing chart to avoid duplication
    if (chart) chart.destroy();

    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Closing Price',
                data: dataPoints,
                borderColor: 'cyan',
                backgroundColor: 'rgba(0, 255, 255, 0.1)',
                tension: 0.3,
                pointRadius: 0,
                fill: true
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    ticks: {
                        color: '#ccc',
                        maxRotation: 90,
                        minRotation: 45
                    },
                    title: {
                        display: true,
                        text: 'Date',
                        color: '#ccc'
                    }
                },
                y: {
                    ticks: {
                        color: '#ccc'
                    },
                    title: {
                        display: true,
                        text: 'Price ($)',
                        color: '#ccc'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#ccc'
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        }
    });
}
